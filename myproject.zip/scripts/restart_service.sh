sudo systemctl restart myproject && sudo systemctl restart nginx
